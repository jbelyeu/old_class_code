#include <iostream>
#include "Car.h"
#include <fstream>
#include <vector>
#include <string>

using namespace std;

int car_specs (string& name, string& color, int price)
{
	cout << "Please input name, color, and price of car:" << endl;
	cin >> name; cin >> color; cin >> price;
	return price;
}

double search_Inventory (vector<Car>& Inventory, string& name, double position)
{
	bool not_found = true;
	for (int i = 0; i < Inventory.size(); i++)
	{
		if (Inventory[i].getName() == name)
		{
			position = i;
			return position;
			not_found = false;
		}
	}
	if (not_found)
	{
			return position;
	}
}
vector<Car> delete_car(vector<Car> Inventory, int position)
{
	vector<Car> to_copy;
	for (int i = 0; i < Inventory.size(); i++)
	{
		if (i != position)
		{
			to_copy.push_back(Inventory[i]);
		}
	}
	//Inventory.clear();
	//Inventory = to_copy;
	//return Inventory;
	return to_copy;
}

int main()
{
	double balance = 10000.00;
	bool run = true;
	bool present = false;
	int option = 0;
	double position = -1;
	vector<Car> Inventory;
	string name;
	string color;
	double price = 0.0;

	while (run)
	{
		cout << "Select option. \n(1) to show inventory \n(2) to show cash balance \n(3) to buy a car \n(4) to sell a car \n(5) to paint a car \n(6) to load a file \n(7) to save to a file \n(8) to quit program" << endl;
		
		cin >> option;

		if (option == 1)//prints name, color, dollar value of each car in Inventory
		{
			for (int i = 0; i < Inventory.size(); i++)
			{
					cout << Inventory[i].toString() << endl;
			}
		}
		else if (option == 2)//prints dollar balance
		{
			cout << "$" << balance << endl;
		}
		else if (option == 3)//adds car to Inventory, subtracts value of car from balance
		{
			//price = car_specs(name, color, price);
			cout << "Enter name, color, and price of car." << endl;
			cin >> name; cin >> color; cin >> price;
			//check balance
			if (balance > price)
			{				
				position = search_Inventory(Inventory, name, position); // int position is unecessary here but simplifies code later; bool present is updated by reference
				//cout << position << endl;
				if (position >= 0) 
				{present = true;}

				cout << position;

				if (present == true)
				{
					cout << "You already entered that vehicle." << endl;
					present = false;
				}
				else//create car, add to Inventory
				{
					Car NewCar = Car(name, color, price);
					Inventory.push_back(NewCar);
					balance -= price;
				}							
				
			}
			else 
			{
				cout << "Insufficient funds!" <<endl;
			}
			position = -1;
		}
		else if (option == 4)//removes car from Inventory, adds value of car to balance
		{
			cout << "Enter name of car." << endl;
			cin >> name;

			position = search_Inventory(Inventory, name, position);
			if (position >= 0) { present = true;}

			if (present == false)
			{
				cout << "Car not found." << endl;
			}
			else //call delete_car function to remove car from inventory
			{
				balance += price;
				Inventory = delete_car(Inventory, position);
			}

		}
		else if (option == 5)//paints car, increase value of car
		{
			cout << "Select car to paint." << endl;
			cin >> name;
			position = search_Inventory(Inventory, name, position);
			if (position >= 0) 
			{
				string new_color;
				cout << "Enter new color." << endl;
				cin >> new_color;
				Inventory[position].paint(new_color);
			}
			else 
			{
				cout << "That car does not exist" << endl;
			}

		}
		else if (option == 6)//adds balance of a file and cars/beans (plus their colors) in that file to inventory
		{
			double new_bal;
			string file;
			ifstream NewFile;
			cout << "What file would you like to open?" << endl;
			cin >> file;

			NewFile.open(file);
			new_bal = NewFile.get();

			
			cout << new_bal;

		}
		else if (option == 7)//saves Inventory to a file
		{
		}
		else if (option == 8) //exits program
		{
			run = false;
		}


	}
//system ("pause");
return 0;
}