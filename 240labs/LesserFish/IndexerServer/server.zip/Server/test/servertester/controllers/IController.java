package servertester.controllers;

public interface IController {

	void initialize();
	
	void operationSelected();
	
	void executeOperation();
}

