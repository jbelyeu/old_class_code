package client.userInterface.dataEntry;

import javax.swing.JTable;





/**
 * @author jon
 *
 */
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Set;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;

import client.facade.ClientFacade;
import client.utilities.*;
import client.utilities.qualityChecker.Corrector;


@SuppressWarnings("serial")
public class DataEntryTable extends JPanel implements CustomStateListener
{
	private EntryTableModel tableModel;
	private JTable table;
	private BatchState batchstate;
	
	private Corrector[] correctors;	


	public DataEntryTable(BatchState state) throws HeadlessException
	{
		this.batchstate = state;
		this.batchstate.addListener(this);
		this.setLayout(new BorderLayout());
		this.addMouseListener(mouseAdapter);
	}

	private MouseAdapter mouseAdapter = new MouseAdapter()
	{
		@Override
		public void mouseReleased(MouseEvent e)
		{
			if ( SwingUtilities.isRightMouseButton(e))
			{
				int column = table.columnAtPoint(e.getPoint()) -1;
				int row = table.rowAtPoint(e.getPoint());
				
				batchstate.setSelectedCell(column + 1, row + 1);
				
				if (batchstate.getGoodTextCells()[column][row] || table.columnAtPoint(e.getPoint()) == 0)
				{
					return;
				}
				
				JPopupMenu menu = new JPopupMenu();
				JMenuItem button = new JMenuItem("See Suggestions");
				
				button.addActionListener(new ActionListener()
				{
					@Override
					public void actionPerformed(ActionEvent e)
					{
						SpellingSuggestionsDialog suggestionWindow = new SpellingSuggestionsDialog(batchstate);
						suggestionWindow.setVisible(true);
					}
				});
				menu.add(button);
				menu.show(table, e.getX(), e.getY());
			}
		}
	};

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#cellSelectedChanged()
	 */
	@Override
	public void cellSelectedChanged()
	{
		if (this.batchstate.getSelectedCell() != null)
		{
			//image, cell are 1-based, this is 0-based
			int column = this.batchstate.getSelectedCell().getField() ;
			int row = this.batchstate.getSelectedCell().getRecord() -1;		
			table.changeSelection(row, column, false, false);
		}
	}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#batchDownloaded()
	 */
	@Override
	public void batchDownloaded()
	{
		tableModel = new EntryTableModel(batchstate);

		table = new JTable(tableModel);
		table.setRowHeight(18);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setCellSelectionEnabled(true);
		table.getTableHeader().setReorderingAllowed(false);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.addMouseListener(mouseAdapter);
		table.setBackground(Color.white);
		
		TableColumnModel columnModel = table.getColumnModel();
		for (int i = 0; i < tableModel.getColumnCount(); ++i)
		{
			TableColumn column = columnModel.getColumn(i);
			column.setPreferredWidth(90);
		}
		for (int i = 1; i < tableModel.getColumnCount(); ++i)
		{
			TableColumn column = columnModel.getColumn(i);
			column.setCellRenderer( new RecordCellRenderer(batchstate) );
		}

		table.setFillsViewportHeight(false);
		this.add(table.getTableHeader(), BorderLayout.NORTH);
		this.add(table, BorderLayout.WEST);	
		correctors = new Corrector[batchstate.getBatchInfo().getNumFields()]; 	
	}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#cellValueChanged()
	 */
	@Override
	public void cellValueChanged()
	{
		this.revalidate();		
	}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#scaled()
	 */
	@Override
	public void scaled()
	{}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#batchSubmitted()
	 */
	@Override
	public void batchSubmitted()
	{}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#invertImage()
	 */
	@Override
	public void invertImage()
	{}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#loadedPositioningData()
	 */
	@Override
	public void loadedPositioningData()
	{}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#highlightsToggled()
	 */
	@Override
	public void highlightsToggled()
	{}		

	
	class RecordCellRenderer extends JLabel implements TableCellRenderer
	{	
		private Border unselectedBorder = BorderFactory.createLineBorder(Color.BLACK);
		private Border selectedBorder = BorderFactory.createLineBorder(Color.BLUE, 2);
		private BatchState batchstate;
		protected ClientFacade facade;	
		
		public RecordCellRenderer(BatchState state)
		{
			setOpaque(true);
			setFont(getFont().deriveFont((float) 12));
			this.batchstate = state;
			this.facade = new ClientFacade();
			this.batchstate = state;
			
			batchstate.setGoodTextCells( new boolean[batchstate.getBatchInfo()
			          .getNumFields()][batchstate.getBatchInfo().getNumRecords()]);
			for (int i = 0; i < batchstate.getBatchInfo().getNumFields(); ++i)
			{
				for (int j = 0; j < batchstate.getBatchInfo().getNumRecords(); ++j)
				{
					batchstate.getGoodTextCells()[i][j] = true;
				}
			}
		}
		
		private void initCorrector(int field)
		{
			Corrector corrector = new Corrector();
			
			String filename = batchstate.getBatchInfo().getFields().get(field).getKnownDataFileName();
			if (filename == null || filename.equals("null") || correctors[field] != null)
			{
				return;
			}
			File knownData = facade.getFile(filename, batchstate.getHost(), batchstate.getPort());
			corrector.useDictionary(knownData);
			correctors[field] = corrector;		
		}
	
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
				boolean hasFocus, int row, int column)
		{		
			String sValue = (String)value;
			boolean wordCorrect = true;
	
			/*It should get the values and search for each one in the spelling corrector. If they are wrong,
			it should generate the list of suggestions and store them in the batch state, then make a 
			listener and box and stuff for them */		
			
			//if there is a value
			if (sValue != null && !sValue.equals(""))
			{
				initCorrector(column-1);
				batchstate.setWordSuggestions(correctors[column - 1].suggestSimilarWords(sValue));
				
				//basically, if the value is wrong
				if (batchstate.getWordSuggestions().length != 1 ||  
					!batchstate.getWordSuggestions()[0].equals(sValue))
				{
					wordCorrect = false;
				}
			}		
					
			if (isSelected)
			{
				this.batchstate.setSelectedCell(column, row + 1);
				this.setBorder(selectedBorder);
				this.setBackground(new Color(0,100,255,80));
			}
			else
			{
				this.setBackground(Color.WHITE);
				this.setBorder(unselectedBorder);
			}
			
			if (! wordCorrect)
			{
				this.setBackground(Color.RED);
				batchstate.getGoodTextCells()[column -1][row] = false;
			}
			else
			{
				batchstate.getGoodTextCells()[column -1][row] = true;
			}
	
			this.setText(sValue);
			return this;
		}
	}
}