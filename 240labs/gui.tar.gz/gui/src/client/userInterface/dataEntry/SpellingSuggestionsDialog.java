/**
 * 
 */
package client.userInterface.dataEntry;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import client.utilities.BatchState;

/**
 * @author jon
 *
 */
@SuppressWarnings("serial")
public class SpellingSuggestionsDialog extends JDialog
{
	BatchState batchstate;
	JList<String> suggestions;
	JButton selectButton;
	
	public SpellingSuggestionsDialog (BatchState state)
	{
		super();
		this.batchstate = state;
		this.setModal(true);
		this.setResizable(false);
		this.setSize(new Dimension(245, 215));
		getContentPane().setLayout(new BoxLayout(getContentPane(), BoxLayout.PAGE_AXIS));
		this.add(Box.createRigidArea(new Dimension(5, 5)));
		this.setUpTop();
		this.setupBottom();
		this.setLocationRelativeTo(null);	
	}
	
	private void setUpTop()
	{		
		suggestions = new JList<String> (batchstate.getWordSuggestions());
		suggestions.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		
		this.suggestions.addMouseListener(new MouseAdapter()
		{
			@Override
			public void mouseClicked(MouseEvent e)
			{
				if (!suggestions.isSelectionEmpty())
				{
					selectButton.setEnabled(true);
				}
			}
		});
		
		JScrollPane scroller = new JScrollPane(suggestions);
		scroller.setBackground(Color.blue);
		
		JPanel top = new JPanel();
		top.setLayout(new BoxLayout(top, BoxLayout.LINE_AXIS));
		top.add(Box.createRigidArea(new Dimension(25, 50)));
		top.add(scroller);
		top.add(Box.createRigidArea(new Dimension(10, 50)));	
		
		this.add(top);
		this.add(Box.createRigidArea(new Dimension(5, 5)));
	}
	
	private void setupBottom()
	{
		JButton cancelButton = new JButton("Cancel");
		cancelButton.addMouseListener(new MouseAdapter()
		{
			@Override
			public void mouseClicked(MouseEvent e)
			{
				closeDialog();
			}
		});
		selectButton = new JButton("Use Suggestion");
		selectButton.setEnabled(false);
		selectButton.addMouseListener(new MouseAdapter()
		{
			@Override
			public void mouseClicked(MouseEvent e)
			{
				useSuggestion();
			}
		});
		
		JPanel bottom = new JPanel();
		bottom.setLayout(new BoxLayout(bottom, BoxLayout.LINE_AXIS));
		bottom.add(Box.createRigidArea(new Dimension(5, 10)));
		bottom.add(cancelButton);
		bottom.add(Box.createRigidArea(new Dimension(5, 10)));
		bottom.add(selectButton);	
		bottom.add(Box.createRigidArea(new Dimension(5, 10)));
		
		this.add(bottom);
		this.add(Box.createRigidArea(new Dimension(5, 5)));
	}
	
	protected void closeDialog()
	{
		this.dispose();
	}
	
	protected void useSuggestion()
	{
		String suggestion = this.suggestions.getSelectedValue();
		int row = this.batchstate.getSelectedCell().getRecord();
		int column = this.batchstate.getSelectedCell().getField();
		
		this.batchstate.setValueAt(suggestion, row -1 , column -1);
		this.dispose();
	}
}
