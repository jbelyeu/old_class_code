/**
 * 
 */
package client.userInterface.rightCorner;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.image.BufferedImage;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JPanel;

import client.utilities.BatchState;
import client.utilities.CustomStateListener;

/**
 * @author jon
 *
 */
@SuppressWarnings("serial")
public class ImageNavigator extends JPanel implements CustomStateListener
{
	BatchState batchstate;
	BufferedImage image;
	
	public ImageNavigator(BatchState state)
	{
		this.batchstate = state;
		batchstate.addListener(this);
		
		this.setLayout(new BoxLayout(this, BoxLayout.LINE_AXIS));
		this.setVisible(true);
	}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#cellSelectedChanged()
	 */
	@Override
	public void cellSelectedChanged()
	{}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#batchDownloaded()
	 */
	@Override
	public void batchDownloaded()
	{
		image = this.batchstate.getImage();
		ViewerPanel viewer = new ViewerPanel();
		JPanel outside = new JPanel();
		outside.setLayout(new BorderLayout());
		outside.add(viewer, BorderLayout.CENTER);
		this.add(Box.createHorizontalGlue());
		this.add(outside);
		this.add(Box.createHorizontalGlue());
		this.setBackground(Color.DARK_GRAY);	
		this.add(Box.createHorizontalGlue());
	}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#cellValueChanged()
	 */
	@Override
	public void cellValueChanged()
	{}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#scaled()
	 */
	@Override
	public void scaled()
	{
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#batchSubmitted()
	 */
	@Override
	public void batchSubmitted()
	{}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#invertImage()
	 */
	@Override
	public void invertImage()
	{}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#loadedPositioningData()
	 */
	@Override
	public void loadedPositioningData()
	{}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#highlightsToggled()
	 */
	@Override
	public void highlightsToggled()
	{}
	
	class ViewerPanel extends JComponent
	{
		private static final long serialVersionUID = 1L;
//		private BufferedImage originalImage;

		public ViewerPanel()
		{
			this.setLayout(new BorderLayout());

//			double scale = this.getHeight() / image.getHeight();
//			Graphics2D graphics = image.createGraphics();
//			
//			graphics.translate(getWidth() / 2.0, getHeight() / 2.0);
//			graphics.scale(scale, scale);			
		}
		
		@Override
		protected void paintComponent(Graphics g)
		{
			int scaleH = image.getHeight() / this.getHeight();
			int scaleW = image.getWidth() / this.getWidth();
			
//			Graphics2D g2 = (Graphics2D) g;
//			g2.scale(scale, scale);
			Image scaledImage = image.getScaledInstance(getWidth(), getHeight(), Image.SCALE_SMOOTH );
			g.drawImage(scaledImage, 50, 50, null);
		}
		
		
	}
}
