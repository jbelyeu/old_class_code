/**
 * 
 */
package client.utilities.qualityChecker;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import client.utilities.qualityChecker.Dictionary.MyNode;
/**
 * @author jon
 *
 */
public class Corrector
{
	private Dictionary dictionary;
	
	public void useDictionary(File file)
	{
		try
		{
			// this function creates the dictionary and loads it
			Scanner scanner = new Scanner(file);
			dictionary = new Dictionary();
			while (scanner.hasNextLine())
			{
				String line = scanner.nextLine();
				String[] words = line.split(",");
				for (String word : words)
				{
					word = word.trim();
					dictionary.add(word);
				}			
			}
			scanner.close();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}

	public Set<String> suggestSimilarWords ( String inputWord )// throws NoSimilarWordFoundException 
	{
		MyNode returnNode = null;
		
		//first, search for word
		returnNode = (MyNode) dictionary.find(inputWord);
		if (returnNode != null)
		{
			Set<String> words = new HashSet<String>();
			words.add(inputWord);
			return words;
		}
		else //then, if not found, call functions to generate the ED1 words to search for
		{
			String[] deletedVars = deleteVariants(inputWord);			
			String[] transposedVariants = transposeVariants(inputWord);
			String[] alteredVariants = alterVariants(inputWord);
			String[] insertedVariants = insertVariants(inputWord);

			
			Map<String, Integer> foundWords = findcaller(deletedVars);
			foundWords.putAll(findcaller(transposedVariants));
			foundWords.putAll(findcaller(alteredVariants));
			foundWords.putAll(findcaller(insertedVariants));
			
			//loop through the edit distance 1 words to generate the ED2 words to search for
			
			foundWords.putAll(generateVarWords(deletedVars));
			foundWords.putAll(generateVarWords(transposedVariants));
			foundWords.putAll(generateVarWords(alteredVariants));
			foundWords.putAll(generateVarWords(insertedVariants));			
						
			return foundWords.keySet();			
		}
	}
	
	private Map<String, Integer> generateVarWords(String[] words)
	{
		Map<String, Integer> foundWords = new HashMap<String, Integer>();
		
		for (String word : words)
		{	
			String[] deletedVars = deleteVariants(word);
			String[] transposedVariants = transposeVariants(word);
			String[] alteredVariants = alterVariants(word);
			String[] insertedVariants = insertVariants(word);
			
			foundWords.putAll(findcaller(deletedVars));
			foundWords.putAll(findcaller(transposedVariants));
			foundWords.putAll(findcaller(alteredVariants));
			foundWords.putAll(findcaller(insertedVariants));
		}
		return foundWords;
	}
	
	//calls the find method for each word in the arrays given it (the variant words already generated)
	private Map<String, Integer> findcaller(String[] words)
	{
		Map<String, Integer> variantWords = new HashMap<String, Integer>();
		
		if (words != null)
		{
			for (String word : words)
			{

				MyNode node = null;

				if (word != null)
				{
					node = (MyNode) dictionary.find(word);
				}
				if (node != null)
				{

					variantWords.put(word, node.getValue());
				}
			}
		}
		return variantWords;		
	}
	
	
	private String[] deleteVariants(String word)
	{
		String[] toReturn = null;
		if (word != null)
		{
			toReturn = new String[word.length()];
		}
		else
		{
			return null;
		}
		for (int i = 0; i < word.length(); ++i)
		{
			String newWord = (word.substring(0, i) + word.substring(i +1, word.length()));
			
			if (newWord.length() > 0)
			{
				toReturn[i] = newWord;
			}
			
		}

		return toReturn;
	}
	
	private String[] transposeVariants(String word)
	{
		if (word != null) 
		{
			if (word.length() < 2)
			{
				String[] toReturn = new String[1];
				toReturn[0] = word;
				return toReturn;
			}
			
			String[] toReturn = new String[word.length() -1 ];
			
			for (int i = 0; i < word.length() -1; ++i)
			{
				String beginning = "", middle1 = "", middle2 = "", end = ""; //these are the first unaltered, first altered, second altered, and second unaltered parts of the new string
				beginning = word.substring(0, i);
				middle1 = word.substring(i, i +1);
				middle2 = word.substring(i +1, i +2);
				
				if ((word.length() - i) > 2)
				{
					end = word.substring(i +2);
				}
				toReturn[i] = beginning + middle2 + middle1 + end;
			}
			return toReturn;
		}
		return null;
	}	
	
	private String[] alterVariants(String word)
	{
		String[] letters = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", 
				"n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", " ", "-", ""};
		if (word != null)
		{
			String[] toReturn = new String[28 * word.length()];
			
			int index = 0;
			
			for (int i = 0; i < word.length(); ++i)
			{
				for (int j = 0; j < letters.length -1; ++j)
				{
					String end = "";
					if (word.length() >= i+1)
					{
						end = word.substring(i + 1);
					}
	
					toReturn[index] = word.substring(0, i) + letters[j] + end;
					index++;
				}
			}
			return toReturn;
		}
		else
		{
			return null;
		}
	}	

	private String[] insertVariants(String word)
	{
		String[] letters = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", 
				"n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", " ", "-", ""};
		if ( word != null )
		{
			String[] toReturn = new String[28 * (word.length()+1)];
			int index = 0;
			
			for (int i = 0; i < word.length(); ++i) //loop builds all words except case of insertion after last letter in word
			{
				for (int j = 0; j < letters.length -1; ++j)
				{
					String beginning = "", end = "";
					
					beginning = word.substring(0, i);
					end = word.substring(i, word.length());
					toReturn[index] = beginning + letters[j] + end;
					index++;
				}
			}
	
			if (word.length() > 0)
			{
				for (int j = 0; j < letters.length -1; ++j) //loop builds only words where case of insertion is after last letter in word
				{
					toReturn[index++] = word + letters[j];
				}
			}
			
			return toReturn;
		}
		else
		{
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString()
	{
		return dictionary.toString();
	}
	
	

}

