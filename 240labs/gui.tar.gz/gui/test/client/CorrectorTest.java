/**
 * 
 */
package client;

import static org.junit.Assert.*;

import java.io.File;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Set;

import junit.framework.TestCase;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import client.utilities.qualityChecker.Corrector;

/**
 * @author jon
 *
 */
public class CorrectorTest
{
	private Corrector corrector;
	File testFile;
	
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception
	{
		corrector = new Corrector();
		testFile = new File("TestValues");
		PrintWriter writer = new PrintWriter(testFile);
		writer.write("test-test, test, test test, ape-man");
		writer.close();
	}
	
	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception
	{
		corrector = null;
		testFile.delete();
	}

	/**
	 * Test method for {@link client.utilities.qualityChecker.Corrector#useDictionary(java.io.File)}.
	 */
	@Test
	public void testUseDictionary()
	{
		try
		{
			corrector.useDictionary(testFile);
		}
		catch (Exception e)
		{
			fail();
		}
	}

	/**
	 * Test method for {@link client.utilities.qualityChecker.Corrector#suggestSimilarWords(java.lang.String)}.
	 */
	@Test
	public void testSuggestSimilarWords()
	{
		corrector.useDictionary(testFile);
		
		
		//0 test-test correct word
		//1 test correct word
		//2 test test correct word
		//3 tst deletion word
		//4 te-st dash insertion
		//5 te st space insertion
		//6 testtest deletion matches two things
		//7 apema-n edit distance two (dash deletion, dash insertion
		//8 apem-a-n edit distance two (dash moved, dash insertion
		//9 testest edit distance two (dash/space deletion, letter deletion)
		//10 testt est both edit distance one and edit distance two (space moved or space/dash deletion, space insertion)
		String terms[] = new String[] {"test-test", "test", "test test", "tst", "te-st", 
				"te st", "testtest", "apema-n", "apema-n", "testest", "testt est" };
		
		String answers0[] = new String[]{"test-test"};
		String answers1[] = new String[]{"test"};
		String answers2[] = new String[]{"test test"};
		String answers345[] = new String[]{"test"};
		String answers6910[] = new String[]{"test-test", "test test"};
		String answers78[] = new String[]{"ape-man"};
		
		try 
		{			
			for (int i = 0; i < terms.length; ++i)
			{
				Set<String> suggestions = corrector.suggestSimilarWords(terms[i]);
				Set<String> answers = null;

				
				switch(i)
				{
					case 0:
						answers = setify(answers0);
						assertEquals(answers, suggestions);
						break;
					case 1:
						answers = setify(answers1);
						assertEquals(answers, suggestions);
						break;
					case 2:
						answers = setify(answers2);
						assertEquals(answers, suggestions);
						break;
					case 3:
					case 4:
					case 5:
						answers = setify(answers345);
						assertEquals(answers, suggestions);
						break;
					case 6:
					case 9:
					case 10:
						answers = setify(answers6910);
						assertEquals(answers, suggestions);
						break;
					case 7:
					case 8:
						answers = setify(answers78);
						assertEquals(answers, suggestions);
						break;
					default:
						fail();						
				}
			}			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	private Set<String> setify(String[] toSetify )
	{
		Set<String> response = new HashSet<String>();

		for (String s: toSetify)
		{
			response.add(s);
		}
		return response;
	}
}
