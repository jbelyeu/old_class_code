///**
// * 
// */
//package client.userInterface;
//
//import java.awt.Color;
//import java.io.IOException;
//
//import javax.swing.JEditorPane;
//import javax.swing.JScrollPane;
//
//import client.utilities.BatchState;
//import client.utilities.CustomStateListener;
//
///**
// * @author jon
// *
// */
//@SuppressWarnings("serial")
//public class FieldHelpPane extends JScrollPane implements CustomStateListener
//{
//	private BatchState batchstate;
//	private JEditorPane helpPane;
//	
//	public FieldHelpPane (BatchState state)
//	{
//		this.batchstate = state;
//		batchstate.addListener(this);
//		this.helpPane = new JEditorPane();
////		this.helpPane
//		this.add(helpPane);
//	}
//
//	/* (non-Javadoc)
//	 * @see client.utilities.CustomStateListener#cellSelectedChanged()
//	 */
//	@Override
//	public void cellSelectedChanged()
//	{
////		JEditorPane tempPane = new JEditorPane();
////		try
////		{
////			tempPane.setPage(batchstate.getBatchInfo().getFields().get(0).getFieldHelpFileName());
////		}
////		catch (IOException e)
////		{
////			e.printStackTrace();
////		}
////		this.helpPane.setToolTipText(tempPane.getText());
////		this.revalidate();
//		
//		try
//		{
//			this.helpPane.setPage(batchstate.getBatchInfo().getFields().get(0).getFieldHelpFileName());
//		}
//		catch (IOException e)
//		{
//			e.printStackTrace();
//		}
//		JScrollPane pane = new JScrollPane(helpPane);
//		pane.setBackground(Color.GREEN);
//		this.add(pane);
//	}
//
//	/* (non-Javadoc)
//	 * @see client.utilities.CustomStateListener#batchDownloaded()
//	 */
//	@Override
//	public void batchDownloaded()
//	{}
//
//	/* (non-Javadoc)
//	 * @see client.utilities.CustomStateListener#cellValueChanged()
//	 */
//	@Override
//	public void cellValueChanged()
//	{}
//
//	/* (non-Javadoc)
//	 * @see client.utilities.CustomStateListener#scaled()
//	 */
//	@Override
//	public void scaled()
//	{}
//
//	/* (non-Javadoc)
//	 * @see client.utilities.CustomStateListener#batchSubmitted()
//	 */
//	@Override
//	public void batchSubmitted()
//	{}
//
//	/* (non-Javadoc)
//	 * @see client.utilities.CustomStateListener#invertImage()
//	 */
//	@Override
//	public void invertImage()
//	{}
//
//	/* (non-Javadoc)
//	 * @see client.utilities.CustomStateListener#loadedPositioningData()
//	 */
//	@Override
//	public void loadedPositioningData()
//	{}
//
//	/* (non-Javadoc)
//	 * @see client.utilities.CustomStateListener#highlightsToggled()
//	 */
//	@Override
//	public void highlightsToggled()
//	{}
//}
