/**
 * 
 */

package client.userInterface;

import java.awt.Color;
import java.awt.Component;
import java.io.IOException;

import javax.swing.JEditorPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;

import client.utilities.BatchState;
import client.utilities.CustomStateListener;

/**
 * @author jon
 *
 */
public class RightTabbedPane extends JTabbedPane implements CustomStateListener
{
	private static final long serialVersionUID = 1L;
	private BatchState batchstate;
	private FieldHelpPane fieldHelp;
	private JPanel imageNavigator;

	public RightTabbedPane(BatchState state)
	{
		this.batchstate = state;
		state.addListener(this);

		fieldHelp = new FieldHelpPane();
		this.addTab("Field Help", fieldHelp);

		imageNavigator = new JPanel();
		this.addTab("Image Navigation", imageNavigator);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see client.utilities.CustomStateListener#cellSelectedChanged()
	 */
	@Override
	public void cellSelectedChanged()
	{
		JEditorPane helpPane = new JEditorPane();
		helpPane.setEditable(false);
		helpPane.setContentType("text/html");
		try
		{
			int fieldindex = batchstate.getSelectedCell().getField() - 1;

			java.net.URL url = new java.net.URL(batchstate.getBatchInfo().getFields()
					.get(fieldindex).getFieldHelpFileName());
			helpPane.setPage(url);

		}
		catch (IOException e)
		{
			e.printStackTrace();
		}

		fieldHelp = new FieldHelpPane(this.batchstate, helpPane);
		this.removeTabAt(0);
		this.removeTabAt(0);
		this.addTab("Field Help", fieldHelp);
		this.addTab("Image Navigation", imageNavigator);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see client.utilities.CustomStateListener#batchDownloaded()
	 */
	@Override
	public void batchDownloaded()
	{
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see client.utilities.CustomStateListener#cellValueChanged()
	 */
	@Override
	public void cellValueChanged()
	{
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see client.utilities.CustomStateListener#scaled()
	 */
	@Override
	public void scaled()
	{
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see client.utilities.CustomStateListener#batchSubmitted()
	 */
	@Override
	public void batchSubmitted()
	{
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see client.utilities.CustomStateListener#invertImage()
	 */
	@Override
	public void invertImage()
	{
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see client.utilities.CustomStateListener#loadedPositioningData()
	 */
	@Override
	public void loadedPositioningData()
	{
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see client.utilities.CustomStateListener#highlightsToggled()
	 */
	@Override
	public void highlightsToggled()
	{
	}

	class FieldHelpPane extends JScrollPane
	{
		private BatchState batchstate;

		public FieldHelpPane(BatchState state, Component comp)
		{
			super(comp);
			this.batchstate = state;

		}

		public FieldHelpPane()
		{
		}
	}

}
