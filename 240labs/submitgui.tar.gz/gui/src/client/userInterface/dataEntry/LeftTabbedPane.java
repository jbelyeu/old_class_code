/**
 * 
 */
package client.userInterface.dataEntry;

import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import client.utilities.BatchState;
import client.utilities.CustomStateListener;

/**
 * @author jon
 *
 */
public class LeftTabbedPane extends JTabbedPane implements CustomStateListener
{
	private static final long serialVersionUID = 1L;
	
	private BatchState batchstate;
	private DataEntryTable tablePanel;

	public LeftTabbedPane(BatchState state)
	{
		this.batchstate = state;
				
		EntryForm form = new EntryForm(this.batchstate);
		tablePanel = new DataEntryTable(this.batchstate);
		JScrollPane tPane = new JScrollPane(tablePanel);		
		
		this.addTab("Form Entry", form);
		this.addTab("Table Entry", tPane);
		
		batchstate.addListener(this);
	}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#cellSelectedChanged()
	 */
	@Override
	public void cellSelectedChanged()
	{}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#batchDownloaded()
	 */
	@Override
	public void batchDownloaded()
	{
		this.tablePanel.setBackground(Color.white);
	}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#cellValueChanged()
	 */
	@Override
	public void cellValueChanged()
	{}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#scaled()
	 */
	@Override
	public void scaled()
	{}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#batchSubmitted()
	 */
	@Override
	public void batchSubmitted()
	{}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#invertImage()
	 */
	@Override
	public void invertImage()
	{}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#loadedPositioningData()
	 */
	@Override
	public void loadedPositioningData()
	{
		this.repaint();
	}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#highlightsToggled()
	 */
	@Override
	public void highlightsToggled()
	{}
}
