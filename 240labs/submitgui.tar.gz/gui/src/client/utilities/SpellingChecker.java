/**
 * 
 */
package client.utilities;

/**
 * @author jon
 *
 */
public class SpellingChecker
{

}
