/**
 * 
 */
package client.facade;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import shared.communication.GetBatchParams;
import shared.communication.GetBatchResult;
import shared.communication.GetProjectsParams;
import shared.communication.GetProjectsResult;
import shared.communication.GetSampleImageParams;
import shared.communication.GetSampleImageResult;
import shared.communication.SubmitBatchParams;
import shared.communication.ValidateUserParams;
import shared.communication.ValidateUserResult;
import client.communication.ClientCommunicator;
import client.communication.ClientException;

/**
 * @author jon
 *
 */
public class ClientFacade
{
	ClientCommunicator communicator;
	
	public ClientFacade()
	{
		communicator = new ClientCommunicator();
	}
	
	
	public ValidateUserResult validateUser(ValidateUserParams params, String host, String port)
	{
		ValidateUserResult result = null;
		try
		{
			result = communicator.validateUser(params, port, host);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}
	
	public GetProjectsResult getProjects (GetProjectsParams params, String host, String port)
	{
		GetProjectsResult result = null;
		try
		{
			result = communicator.getProjects(params, port, host);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}
	
	public BufferedImage getSampleImage(GetSampleImageParams params, String host, String port)
	{
		GetSampleImageResult result = null;		
		String[] urlArray = params.getPort().split("/");
		params.setPort(urlArray[0] + "/GetFile/");
		
		try 
		{
			result = communicator.getSampleImage(params, host, port);
		} 
		catch (Exception e1) 
		{
			e1.printStackTrace();
		}
		
		
		BufferedImage image = null;
		try
		{
			String url = result.getImageURL();
			image = ImageIO.read(communicator.getFile(url));
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		} 
		catch (ClientException e) 
		{
			e.printStackTrace();
		}
		return image;
	}
	
	public GetBatchResult downloadBatch(GetBatchParams params, String host, String port)
	{
		params.setPort(params.getPort() + "/GetFile/");
		BufferedImage image = null;
		GetBatchResult result = null;
		
		try
		{
			result = communicator.getBatch(params, port, host);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}
	
	public BufferedImage getImage(String url, String host, String port)
	{	
		BufferedImage image = null;
		try
		{
			image = ImageIO.read(communicator.getFile(url));
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		} 
		catch (ClientException e) 
		{
			e.printStackTrace();
		}
		return image;
	}
	
	public File getFile(String url, String host, String port)
	{	
		File file = null;
		try
		{
			file = communicator.getFile(url);
		} 
		catch (ClientException e) 
		{
			e.printStackTrace();
		}
		return file;
	}
	
	
	public void submitBatch(SubmitBatchParams params, String host, String port)
	{
		try
		{
			communicator.SubmitBatch(params, port, host);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
