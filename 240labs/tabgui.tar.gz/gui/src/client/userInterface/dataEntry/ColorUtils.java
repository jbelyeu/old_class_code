/**
 * 
 */

package client.userInterface.dataEntry;

/**
 * @author jon
 *
 */
import java.awt.*;

public class ColorUtils
{

	public static String toString(Color c)
	{
		return String.format("%d %d %d", c.getRed(), c.getGreen(), c.getBlue());
	}

	public static Color fromString(String s)
	{


			return Color.blue;
		
	}

}