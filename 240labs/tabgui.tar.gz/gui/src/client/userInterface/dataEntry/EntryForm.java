/**
 * 
 */
package client.userInterface.dataEntry;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import client.utilities.BatchState;
import client.utilities.CustomStateListener;

/**
 * @author jon
 *
 */
@SuppressWarnings("serial")
public class EntryForm extends JPanel implements CustomStateListener
{
	private BatchState batchstate;
	private JList<Integer> recordNums; //record number list
	private Vector<JPanel> panels;
	private ArrayList<JTextField> entryFields;	
	private JPanel form;
	
	public EntryForm(BatchState state)
	{
		this.batchstate = state;
		this.batchstate.addListener(this);
		this.setLayout(new BorderLayout());
	}


	
	/**
	 * Sets up the class with form
	 */
	private void setUp()
	{
		Integer[] numbers = new Integer[this.batchstate.getBatchInfo().getNumRecords()];
		for (int i = 0; i < numbers.length; ++i)
		{
			numbers[i] = i+1;
		}
		
		this.recordNums = new JList<Integer>(numbers);
		this.recordNums.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		this.recordNums.addListSelectionListener(new ListSelectionListener()
		{
			@Override
			public void valueChanged(ListSelectionEvent arg0)
			{
				if (entryFields != null) //tells me the object is ready to init the records
				{
					switchRecords();
				}
			}
		});
		
		if (this.batchstate.getSelectedCell() != null)
		{
			this.recordNums.setSelectedIndex(batchstate.getSelectedCell().getRecord() -1);
		}
		else
		{
			this.recordNums.setSelectedIndex(0);
		}		
		JScrollPane numPane = new JScrollPane(recordNums);
		
		recordNums.addMouseListener(new MouseAdapter()
		{
			@Override
			public void mouseClicked(MouseEvent e)
			{
				recordClicked();
			}
		});
		
		this.add(numPane, BorderLayout.WEST);
		numPane.setMinimumSize(new Dimension(10, 5 * numbers.length));
		numPane.setPreferredSize(new Dimension(50, 5 * numbers.length));

		this.listCreator(); //initializes the list of panels with their values and labels
		JScrollPane formPane = new JScrollPane(form);
		this.add(formPane, BorderLayout.CENTER);
		this.setVisible(true);
	}
	
	//called by setup()
	private void listCreator()
	{
		panels = new Vector<JPanel>();
		entryFields = new ArrayList<JTextField>();
		
		int fields = this.batchstate.getBatchInfo().getNumFields();
		this.form = new JPanel();
		form.setLayout(new BoxLayout(form, BoxLayout.PAGE_AXIS));
		this.form.add(Box.createVerticalGlue());
		
		for (int i = 0; i < fields; ++i)
		{
			JPanel panel = new JPanel();
			panel.setLayout(new BoxLayout(panel, BoxLayout.LINE_AXIS));
			
			JLabel label = new JLabel(this.batchstate.getBatchInfo().
									getFields().get(i).getFieldTitle());
			
			panel.add(label);
			panel.add(Box.createHorizontalGlue());
			panel.add(Box.createRigidArea(new Dimension(10, 20)));
			
			JTextField entry = new JTextField();
			entry.setPreferredSize(new Dimension(300, 25));
			entry.setMinimumSize(new Dimension(300, 25));
			entry.setMaximumSize(new Dimension(300, 25));	
			entry.addFocusListener(new FocusListener()
			{
				@Override
				public void focusGained(FocusEvent arg0)
				{
					fieldClicked();					
				}

				@Override
				public void focusLost(FocusEvent arg0)
				{
					saveValue();
				}				
			});
			
			entryFields.add(entry);
			panel.add(entry);
			panel.add(Box.createRigidArea(new Dimension(30, 20)));
			
			panels.add(panel); //add to vector to keep track
			this.form.add(panel);
			this.form.add(Box.createVerticalGlue());	
		}
		this.initFields();
	}
	
	
	@Override
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
	}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#cellSelectedChanged()
	 */
	@Override
	public void cellSelectedChanged()
	{
		if (this.batchstate != null && this.batchstate.getSelectedCell() != null)
		{
			int column = this.batchstate.getSelectedCell().getField() -1;
			int row = this.batchstate.getSelectedCell().getRecord() -1 ;
			
			this.recordNums.setSelectedIndex(row);
			this.entryFields.get(column).requestFocusInWindow();
			this.repaint();
		}}
	

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#batchDownloaded()
	 */
	@Override
	public void batchDownloaded()
	{
		setUp();
	}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#cellValueChanged()
	 */
	@Override
	public void cellValueChanged()
	{}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#scaled()
	 */
	@Override
	public void scaled()
	{}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#batchSubmitted()
	 */
	@Override
	public void batchSubmitted()
	{}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#invertImage()
	 */
	@Override
	public void invertImage()
	{}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#loadedPositioningData()
	 */
	@Override
	public void loadedPositioningData()
	{
		setUp();
	}

	/* (non-Javadoc)
	 * @see client.utilities.CustomStateListener#highlightsToggled()
	 */
	@Override
	public void highlightsToggled()
	{}
	
	private void fieldClicked()
	{		
		for (int i = 0; i < entryFields.size(); ++i)
		{
			JTextField field = entryFields.get(i);
			
			if (field.hasFocus())
			{
				int recordNum = (int)this.recordNums.getSelectedValue();				
				this.batchstate.setSelectedCell(i + 1, recordNum);	
				break;
			}
		}
	}
	
	private void recordClicked()
	{		
		int recordNum = (int)recordNums.getSelectedValue();
		int fieldNum = 1;		
		
		if (this.batchstate.getSelectedCell() != null)
		{
			fieldNum = this.batchstate.getSelectedCell().getField();
		}
		
		this.batchstate.setSelectedCell(fieldNum, recordNum);	
	}
	
	private void saveValue()
	{}
	
	private void switchRecords()
	{}
	
	private void initFields()	
	{}
	
	private JTextField getClickedField(int index)
	{
		for (int i = 0; i < entryFields.size(); ++i)
		{
			JTextField field = entryFields.get(i);			
			if (field.hasFocus())
			{
				index = i;
				return field;
			}
		}
		return null;
	}
}
